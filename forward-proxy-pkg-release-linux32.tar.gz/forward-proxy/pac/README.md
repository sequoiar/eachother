edit proxy rules in black.pac or white.pack
